# Prefixer

## How To use

Run `ruby prefixer.rb YOUR_FILE`

## Gem used

- Pry

